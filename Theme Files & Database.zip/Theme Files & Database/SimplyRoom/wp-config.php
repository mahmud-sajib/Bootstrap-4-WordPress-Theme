<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'simply_room_db');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');


/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'jEcs>]/%7W<  8X!80,]1<zq$GVU1z|R?YQbu$-( N2N[T7,7J^-Qbl1_Lt3UV;_');
define('SECURE_AUTH_KEY',  '^ZhR~dCgz^kv22C{U&^7CPkx!-4~+P2g2uNJmII^1,=9!^sCcRi/k~!</w_j]Uys');
define('LOGGED_IN_KEY',    'Ir1j3^L?N 7a@EFj+#]rg?F=zPuOZx38B{QIEsW}fL6O*7=i>2}:tZS {Go%,9cf');
define('NONCE_KEY',        'ejX)ON5;JJUbr-hV}r!&4{O!/Fg6^}#1Qg: _7GO[!]G:#H?7 sNPOSX2b->W2sr');
define('AUTH_SALT',        'S4r(tSEarVLe77mO2RDO.)U9Jmzr<3x#;-v%n%7S!4jNyj)bFop25ShS;Vo&T-G8');
define('SECURE_AUTH_SALT', '?jsIvOxlhRia<+ !&Q-6<+y!T,xaR#HA(OZMei{Jutsyd5upo4|-YeXpjteQ2-lY');
define('LOGGED_IN_SALT',   'Vp8aS^2x~{wsZz ^}e:p{:~]=FV/ff9YuN.9I1U&9c{^Z R9&QOW$gD*xe:|q<V3');
define('NONCE_SALT',       'pah$Ce/[HRp#4hlw)#SHzDUSpqvRATW3B7d0O}D:^@_Q+Z@CCRplw5`O]zdA$$eg');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
